import sys
def lsn(d,n): return d[n*256:(n+1)*256]
def u24(b): return (b[0]<<16)|(b[1]<<8)|b[2]
def fd_segs(d,fdl):
    fd=lsn(d,fdl); size=int.from_bytes(fd[9:13],'big'); segs=[]
    for i in range(48):
        e=fd[16+i*5:21+i*5]; l=u24(e); c=(e[3]<<8)|e[4]
        if c==0: break
        segs.append((l,c))
    return fd[0],size,segs
def read_file(d,fdl):
    att,size,segs=fd_segs(d,fdl); out=b''
    for l,c in segs: out+=d[l*256:(l+c)*256]
    return out[:size]
def ls(d,fdl):
    data=read_file(d,fdl); ents=[]
    for i in range(0,len(data),32):
        e=data[i:i+32]
        if e[0]==0: continue
        name=bytearray(); 
        for ch in e[:29]:
            name.append(ch&0x7f)
            if ch&0x80: break
        ents.append((name.decode('latin1'),u24(e[29:32])))
    return ents
d=open(sys.argv[1],'rb').read()
l0=lsn(d,0); print('DD.TOT',u24(l0[0:3]),'DD.TKS',l0[3],'DD.MAP',int.from_bytes(l0[4:6],'big'),'DD.BIT',int.from_bytes(l0[6:8],'big'),'DD.DIR',u24(l0[8:11]),'DD.FMT',hex(l0[16]),'DD.SPT',int.from_bytes(l0[17:19],'big'))
root=u24(l0[8:11])
for n,f in ls(d,root):
    att,size,segs=fd_segs(d,f); print(' ',n.ljust(12),'FD',f,'taille',size,'segments',segs)
if len(sys.argv)>2:
    ref=open(sys.argv[2],'rb').read()
    for n,f in ls(d,root):
        if n.lower()=='b1':
            data=read_file(d,f); print('b1 == reference ?', data==ref, len(data), len(ref))

ESP32-CoCo3-PRO 1.0 - PC tools (Python 3.7 or newer)
================================================

coco_share.py / coco_share.bat
    Shares a folder of your PC with the emulator over Wi-Fi. In the drive
    browser of the emulator (F12 > DATA STORAGE > DRIVE n), press P to browse
    it; what the CoCo writes is sent back to the .DSK file (a .bak copy is kept).
      python coco_share.py                         (last folder, or this one)
      python coco_share.py --dir "D:\CoCo\Disks"   (kept for the next times)
      python coco_share.py --port 6809 --read-only
    Windows: double-click coco_share.bat. The 6-digit PIN shown is typed once on
    the CoCo. It is saved in coco_share.ini next to the script: keep that file
    private. Local network only.

make_splash.py   (needs Pillow: pip install pillow)
    Makes the boot screen files for /ESP-BOOT on the SD card.
      python make_splash.py film.gif                  -> SPLASH.CCV
      python make_splash.py images_folder --fps 10    -> SPLASH.CCV
      python make_splash.py --slides photos -o SLIDES -> SLIDES/*.BMP
      python make_splash.py --wav music.wav           -> SPLASH.WAV

rsdos.py disk.dsk [NAME out.bin]   lists an RS-DOS disk image (or extracts NAME)
detok.py file.bas    prints a tokenized CoCo 3 BASIC program as text
rbf.py disk.dsk      lists an OS-9 (RBF) disk image

make_flh.py firmware.bin firmware.FLH [--text "ESP32-CoCo3-PRO v1.0"]
    turns a compiled .bin into a .FLH file (checksum verified by the board
    before flashing). Copy it into /FLASHNOW on the SD card, or use
    F12 > SYSTEM > FIRMWARE UPDATE.

-------------------------------------------------------------------------------
Outils pour PC (Python 3.7 ou plus récent)

coco_share.py / .bat : partage d'un dossier du PC par le Wi-Fi (touche P dans
    le navigateur des lecteurs) ; le PIN est gardé dans coco_share.ini (à ne
    pas diffuser).
make_splash.py : fichiers de l'écran d'accueil (/ESP-BOOT) ; Pillow requis.
rsdos.py : liste une disquette RS-DOS ; detok.py : programme BASIC en texte ;
rbf.py : liste un disque OS-9 ; make_flh.py : .bin compilé -> .FLH.

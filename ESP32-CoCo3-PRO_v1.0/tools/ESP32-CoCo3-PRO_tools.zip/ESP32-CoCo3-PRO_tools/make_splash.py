#!/usr/bin/env python3
# ===========================================================================
# make_splash.py — ESP32-CoCo3-Pro : fabrique l'écran d'accueil de la SD
#
#   python make_splash.py film.gif                 -> SPLASH.CCV (film)
#   python make_splash.py dossier_images/ --fps 10 -> SPLASH.CCV (images triées par nom)
#   python make_splash.py film.gif --size 320x240 --fps 12 -o SPLASH.CCV
#   python make_splash.py --slides photos/ -o SLIDES   -> SLIDES/*.BMP (320x240, 24 bits)
#   python make_splash.py --wav musique.wav            -> SPLASH.WAV (22050 Hz, mono, 16 bits)
#
# Copier ensuite SPLASH.CCV / SPLASH.WAV / SLIDES dans le dossier /ESP-BOOT de la
# carte SD (ou par la page web), puis F12 > SYSTEM > BOOT SCREEN = SD CARD.
#
# Format SPLASH.CCV : en-tête de 16 octets « CCV1 », largeur, hauteur,
# images/s x 10, nombre d'images (16 bits, petit-boutiste), 4 octets à 0 ;
# puis les images brutes, 1 octet par point : bits BBGGGRRR (couleurs de la
# sortie VGA de la carte). Taille par défaut 160x120 (agrandie x2 à l'écran) :
# 19 Ko par image, la carte SD suit sans peine à 15 images/s. 320x240 : 75 Ko
# par image, garder 8-10 images/s.
# Besoin : Python 3 et Pillow (pip install pillow). Pour une vidéo MP4,
# l'exporter d'abord en GIF ou en suite d'images (ffmpeg, un éditeur vidéo).
# ===========================================================================
import argparse, os, struct, sys, wave

def need_pillow():
    try:
        from PIL import Image, ImageSequence  # noqa
        return Image, ImageSequence
    except ImportError:
        sys.exit("Pillow manque : pip install pillow")

def rgb332(r, g, b):
    return (r >> 5) | ((g >> 5) << 3) | (b & 0xC0)

def to332(img):
    img = img.convert('RGB')
    px = img.tobytes()
    out = bytearray(len(px) // 3)
    for i in range(len(out)):
        r, g, b = px[3 * i], px[3 * i + 1], px[3 * i + 2]
        out[i] = (r >> 5) | ((g >> 5) << 3) | (b & 0xC0)
    return bytes(out)

def fit(img, w, h, Image):
    img = img.convert('RGB')
    iw, ih = img.size
    s = min(w / iw, h / ih)
    nw, nh = max(1, int(iw * s)), max(1, int(ih * s))
    img = img.resize((nw, nh), Image.LANCZOS)
    canvas = Image.new('RGB', (w, h))
    canvas.paste(img, ((w - nw) // 2, (h - nh) // 2))
    return canvas

def frames_from(src, Image, ImageSequence):
    if os.path.isdir(src):
        names = sorted(n for n in os.listdir(src) if n.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')))
        for n in names:
            yield Image.open(os.path.join(src, n)), None
    else:
        im = Image.open(src)
        for fr in ImageSequence.Iterator(im):
            yield fr.copy(), fr.info.get('duration')

def make_ccv(src, out, size, fps):
    Image, ImageSequence = need_pillow()
    w, h = size
    data = []; durs = []
    for fr, d in frames_from(src, Image, ImageSequence):
        data.append(to332(fit(fr, w, h, Image)))
        if d: durs.append(d)
        if len(data) >= 65535: break
    if not data: sys.exit("aucune image trouvee")
    if fps is None:
        fps = round(1000.0 / (sum(durs) / len(durs)), 1) if durs else 10.0
    fps = max(1.0, min(60.0, fps))
    with open(out, 'wb') as f:
        f.write(b'CCV1' + struct.pack('<HHHH', w, h, int(round(fps * 10)), len(data)) + b'\0' * 4)
        for d in data: f.write(d)
    print(f"{out} : {len(data)} images {w}x{h}, {fps} images/s, {os.path.getsize(out) // 1024} Ko")

def make_slides(src, outdir):
    Image, _ = need_pillow()
    os.makedirs(outdir, exist_ok=True)
    names = sorted(n for n in os.listdir(src) if n.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')))
    for i, n in enumerate(names[:64]):
        img = fit(Image.open(os.path.join(src, n)), 320, 240, Image)
        dst = os.path.join(outdir, f"S{i + 1:02d}.BMP")
        img.save(dst, 'BMP')
        print(dst)

def make_wav(src, out, rate=22050):
    with wave.open(src, 'rb') as w:
        ch, sw, fr, n = w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()
        raw = w.readframes(n)
    if sw not in (1, 2): sys.exit("WAV 8 ou 16 bits seulement (exporter en PCM 16 bits)")
    # en mono 16 bits
    samples = []
    step = sw * ch
    for i in range(0, len(raw) - step + 1, step):
        acc = 0
        for c in range(ch):
            o = i + c * sw
            acc += (raw[o] - 128) << 8 if sw == 1 else struct.unpack_from('<h', raw, o)[0]
        samples.append(acc // ch)
    # rééchantillonnage linéaire
    outn = int(len(samples) * rate / fr)
    res = bytearray()
    for k in range(outn):
        x = k * fr / rate; i = int(x); f = x - i
        a = samples[i] if i < len(samples) else 0
        b = samples[i + 1] if i + 1 < len(samples) else a
        res += struct.pack('<h', max(-32768, min(32767, int(a + (b - a) * f))))
    with wave.open(out, 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(bytes(res))
    print(f"{out} : {outn / rate:.1f} s, {rate} Hz mono 16 bits, {os.path.getsize(out) // 1024} Ko")

def main():
    ap = argparse.ArgumentParser(description="Ecran d'accueil ESP32-CoCo3-Pro (SPLASH.CCV, SLIDES, SPLASH.WAV)")
    ap.add_argument('src', nargs='?', help="GIF anime ou dossier d'images (film)")
    ap.add_argument('-o', '--out')
    ap.add_argument('--size', default='160x120', help="160x120 (defaut, agrandi x2) ou 320x240")
    ap.add_argument('--fps', type=float, help="images par seconde (defaut : celle du GIF, sinon 10)")
    ap.add_argument('--slides', help="dossier de photos -> dossier SLIDES de BMP 320x240")
    ap.add_argument('--wav', help="fichier WAV -> SPLASH.WAV 22050 Hz mono")
    a = ap.parse_args()
    if a.slides: make_slides(a.slides, a.out or 'SLIDES'); return
    if a.wav: make_wav(a.wav, a.out or 'SPLASH.WAV'); return
    if not a.src: ap.print_help(); return
    w, h = (int(v) for v in a.size.lower().split('x'))
    if w > 320 or h > 240: sys.exit("taille maximale 320x240")
    make_ccv(a.src, a.out or 'SPLASH.CCV', (w, h), a.fps)

if __name__ == '__main__':
    main()

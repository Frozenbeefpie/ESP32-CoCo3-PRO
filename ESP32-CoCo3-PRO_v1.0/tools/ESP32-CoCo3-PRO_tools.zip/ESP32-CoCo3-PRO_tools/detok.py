import sys
T=["FOR","GO","REM","'","ELSE","IF","DATA","PRINT","ON","INPUT","END","NEXT","DIM","READ","RUN","RESTORE","RETURN","STOP","POKE","CONT","LIST","CLEAR","NEW","CLOAD","CSAVE","OPEN","CLOSE","LLIST","SET","RESET","CLS","MOTOR","SOUND","AUDIO","EXEC","SKIPF","TAB(","TO","SUB","THEN","NOT","STEP","OFF","+","-","*","/","^","AND","OR",">","=","<","DEL","EDIT","TRON","TROFF","DEF","LET","LINE","PCLS","PSET","PRESET","SCREEN","PCLEAR","COLOR","CIRCLE","PAINT","GET","PUT","DRAW","PCOPY","PMODE","PLAY","DLOAD","RENUM","FN","USING","DIR","DRIVE","FIELD","FILES","KILL","LOAD","LSET","MERGE","RENAME","RSET","SAVE","WRITE","VERIFY","UNLOAD","DSKINI","BACKUP","COPY","DSKI$","DSKO$","DOS","WIDTH","PALETTE","HSCREEN","LPOKE","HCLS","HCOLOR","HPAINT","HCIRCLE","HLINE","HGET","HPUT","HBUFF","HPRINT","ERR","BRK","LOCATE","HSTAT","HSET","HRESET","HDRAW","CMP","RGB","ATTR"]
F=["SGN","INT","ABS","USR","RND","SIN","PEEK","LEN","STR$","VAL","ASC","CHR$","EOF","JOYSTK","LEFT$","RIGHT$","MID$","POINT","INKEY$","MEM","ATN","COS","TAN","EXP","FIX","LOG","POS","SQR","HEX$","VARPTR","INSTR","TIMER","PPOINT","STRING$","CVN","FREE","LOC","LOF","MKN$","AS","LPEEK","BUTTON","HPOINT","ERNO","ERLIN"]
d=open(sys.argv[1],'rb').read()
i=3 if d[0]==0xFF else 0
while i+4<=len(d):
    nxt=(d[i]<<8)|d[i+1]
    if nxt==0: break
    ln=(d[i+2]<<8)|d[i+3]; i+=4; out=''
    while d[i]!=0:
        c=d[i]
        if c==0xFF: i+=1; k=d[i]-0x80; out+=F[k] if 0<=k<len(F) else '{FF%02X}'%d[i]
        elif c>=0x80: k=c-0x80; out+=T[k] if k<len(T) else '{%02X}'%c
        else: out+=chr(c)
        i+=1
    i+=1; print(ln,out)

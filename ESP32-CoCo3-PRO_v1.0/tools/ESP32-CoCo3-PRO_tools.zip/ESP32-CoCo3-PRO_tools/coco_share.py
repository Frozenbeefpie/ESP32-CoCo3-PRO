#!/usr/bin/env python3
# ===========================================================================
# coco_share.py — partage d'un dossier du PC avec l'ESP32-CoCo3 (Wi-Fi, W2)
#
# Le menu F12 -> D de l'ESP32-CoCo3 (touche P) parcourt ce dossier et monte
# l'image .DSK choisie sur les lecteurs 0-3 de l'émulateur (Disk BASIC normal,
# tous les jeux). Les écritures du CoCo sont renvoyées dans le fichier du PC
# (copie .bak gardée à la première écriture).
#
# Python 3.7 ou plus récent, bibliothèque standard seulement.
#   python coco_share.py                      (dossier gardé, sinon celui du script)
#   python coco_share.py --dir "D:\CoCo\Disks"  (gardé pour les fois suivantes)
#   coco_share.bat : même chose par un double-clic (Windows)
#   python coco_share.py --dir ~/coco --port 6809 --read-only
#
# Sécurité :
#   - code PIN à 6 chiffres affiché ici, à taper une fois sur le CoCo
#     (gardé dans le fichier coco_share.ini à côté du script) ;
#   - réseau local seulement (adresses privées) ;
#   - accès limité au dossier partagé (pas de « .. », pas de liens vers
#     l'extérieur) ; écriture seulement dans des fichiers .DSK existants.
#
# Protocole (HTTP/1.0, en-tête X-CoCo-Pin) :
#   GET /api/hello                       -> "COCO3SHARE 1\n<nom>\n"
#   GET /api/list?p=/dossier             -> lignes "D <nom>" ou "F <taille> <nom>"
#   GET /api/get?p=/x.dsk[&off=N&len=M]  -> octets
#   PUT /api/put?p=/x.dsk                -> écrit le fichier (même taille)
#   UDP 6809 : "COCO3SHARE?" -> "COCO3SHARE <port tcp> <nom>"
# ===========================================================================
import argparse
import configparser
import http.server
import ipaddress
import os
import random
import socket
import socketserver
import sys
import threading
import time
import urllib.parse

VERSION = "1"
MAX_FILE = 4 * 1024 * 1024          # plus grande image servie / reçue
LIST_EXT = (".dsk", ".rom", ".ccc")  # fichiers montrés (les dossiers toujours) ; 7t7 : cartouches .ROM / .CCC
WRITE_EXT = (".dsk",)

def log(msg):
    print(time.strftime("%H:%M:%S ") + msg, flush=True)

def is_private(ip):
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return a.is_private or a.is_loopback or a.is_link_local

class Share:
    def __init__(self, root, pin, name, read_only):
        self.root = os.path.realpath(root)
        self.pin = pin
        self.name = name
        self.read_only = read_only
        self.backed_up = set()
        self.lock = threading.Lock()

    def resolve(self, rel):
        # chemin du CoCo ("/A/B.DSK") -> chemin réel dans le dossier partagé
        rel = (rel or "/").replace("\\", "/")
        parts = [p for p in rel.split("/") if p not in ("", ".")]
        if any(p == ".." for p in parts):
            return None
        full = os.path.realpath(os.path.join(self.root, *parts))
        if full != self.root and not full.startswith(self.root + os.sep):
            return None
        return full

class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "CoCoShare/" + VERSION
    protocol_version = "HTTP/1.0"

    def log_message(self, fmt, *args):      # journal maison (plus court)
        pass

    def send_text(self, code, text):
        data = text.encode("utf-8", "replace")
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def check(self):
        ip = self.client_address[0]
        if not is_private(ip):
            log("refused %s (not on the local network)" % ip)
            self.send_text(403, "local network only\n")
            return None
        if self.headers.get("X-CoCo-Pin", "") != self.server.share.pin:
            log("refused %s (wrong PIN)" % ip)
            self.send_text(401, "wrong PIN\n")
            return None
        url = urllib.parse.urlsplit(self.path)
        return url.path, urllib.parse.parse_qs(url.query)

    def do_GET(self):
        r = self.check()
        if not r:
            return
        path, q = r
        sh = self.server.share
        rel = q.get("p", ["/"])[0]
        if path == "/api/hello":
            log("hello from %s" % self.client_address[0])
            self.send_text(200, "COCO3SHARE %s\n%s\n" % (VERSION, sh.name))
            return
        full = sh.resolve(rel)
        if full is None:
            self.send_text(400, "bad path\n")
            return
        if path == "/api/list":
            if not os.path.isdir(full):
                self.send_text(404, "not a folder\n")
                return
            dirs, files = [], []
            try:
                for e in os.scandir(full):
                    if e.name.startswith("."):
                        continue
                    if e.is_dir(follow_symlinks=False):
                        dirs.append(e.name)
                    elif e.is_file() and e.name.lower().endswith(LIST_EXT):
                        files.append((e.name, e.stat().st_size))
            except OSError as ex:
                self.send_text(500, "%s\n" % ex)
                return
            dirs.sort(key=str.lower)
            files.sort(key=lambda f: f[0].lower())
            out = ["D %s" % d for d in dirs] + ["F %d %s" % (s, n) for n, s in files]
            log("list %s (%d folders, %d files) for %s" % (rel, len(dirs), len(files), self.client_address[0]))
            self.send_text(200, "\n".join(out) + ("\n" if out else ""))
            return
        if path == "/api/get":
            if not os.path.isfile(full):
                self.send_text(404, "no such file\n")
                return
            size = os.path.getsize(full)
            if size > MAX_FILE:
                self.send_text(413, "file too large\n")
                return
            off = int(q.get("off", ["0"])[0] or 0)
            ln = int(q.get("len", [str(size)])[0] or size)
            off = max(0, min(off, size))
            ln = max(0, min(ln, size - off))
            with open(full, "rb") as f:
                f.seek(off)
                data = f.read(ln)
            if off == 0 and ln == size:
                log("send %s (%d bytes) to %s" % (rel, size, self.client_address[0]))
            self.send_response(200)
            self.send_header("Content-Type", "application/octet-stream")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        self.send_text(404, "unknown request\n")

    def do_PUT(self):
        r = self.check()
        if not r:
            return
        path, q = r
        sh = self.server.share
        if path != "/api/put":
            self.send_text(404, "unknown request\n")
            return
        if sh.read_only:
            self.send_text(403, "read-only share\n")
            return
        rel = q.get("p", [""])[0]
        full = sh.resolve(rel)
        if full is None or not os.path.isfile(full) or not full.lower().endswith(WRITE_EXT):
            self.send_text(400, "bad path\n")
            return
        try:
            ln = int(self.headers.get("Content-Length", "-1"))
        except ValueError:
            ln = -1
        if ln < 0 or ln > MAX_FILE:
            self.send_text(411, "length required\n")
            return
        data = b""
        while len(data) < ln:
            chunk = self.rfile.read(ln - len(data))
            if not chunk:
                break
            data += chunk
        if len(data) != ln:
            self.send_text(400, "short body\n")
            return
        if ln != os.path.getsize(full):
            self.send_text(409, "size changed\n")
            return
        with sh.lock:
            if full not in sh.backed_up and not os.path.exists(full + ".bak"):
                with open(full, "rb") as src, open(full + ".bak", "wb") as dst:
                    dst.write(src.read())
            sh.backed_up.add(full)
            tmp = full + ".tmp"
            with open(tmp, "wb") as f:
                f.write(data)
            os.replace(tmp, full)
        log("saved %s (%d bytes) from %s" % (rel, ln, self.client_address[0]))
        self.send_text(200, "OK\n")

class Server(socketserver.ThreadingMixIn, http.server.HTTPServer):
    daemon_threads = True
    allow_reuse_address = True

def udp_responder(port, name, stop):
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind(("", port))
    except OSError as ex:
        log("discovery disabled (UDP port %d: %s)" % (port, ex))
        return
    s.settimeout(1.0)
    while not stop.is_set():
        try:
            data, addr = s.recvfrom(64)
        except socket.timeout:
            continue
        except OSError:
            continue
        if data.strip() == b"COCO3SHARE?" and is_private(addr[0]):
            s.sendto(("COCO3SHARE %d %s" % (port, name)).encode(), addr)
            log("found by %s" % addr[0])

def load_pin(ini_path, forced):
    cfg = configparser.ConfigParser()
    cfg.read(ini_path)
    pin = forced or cfg.get("share", "pin", fallback="")
    if not (len(pin) == 6 and pin.isdigit()):
        pin = "%06d" % random.SystemRandom().randint(0, 999999)
    if not cfg.has_section("share"):
        cfg.add_section("share")
    cfg.set("share", "pin", pin)
    try:
        with open(ini_path, "w") as f:
            cfg.write(f)
    except OSError:
        pass
    return pin

def load_dir(ini_path):
    cfg = configparser.ConfigParser()
    cfg.read(ini_path)
    d = cfg.get("share", "dir", fallback="")
    return d if d and os.path.isdir(d) else ""

def save_dir(ini_path, root):
    cfg = configparser.ConfigParser()
    cfg.read(ini_path)
    if not cfg.has_section("share"):
        cfg.add_section("share")
    cfg.set("share", "dir", root)
    try:
        with open(ini_path, "w") as f:
            cfg.write(f)
    except OSError:
        pass

def local_ips():
    ips = set()
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    return sorted(ips)

def main():
    ap = argparse.ArgumentParser(description="Share a folder of .DSK images with the ESP32-CoCo3")
    ap.add_argument("--dir", default="", help="folder to share (remembered; default: the folder of this script)")
    ap.add_argument("--port", type=int, default=6809, help="TCP and UDP port (default 6809)")
    ap.add_argument("--name", default=socket.gethostname(), help="name shown on the CoCo")
    ap.add_argument("--pin", default="", help="force a 6-digit PIN")
    ap.add_argument("--read-only", action="store_true", help="never write to the PC files")
    a = ap.parse_args()
    # Dossier partagé : --dir (gardé dans coco_share.ini), sinon celui gardé,
    # sinon le dossier du script. Jamais le dossier courant : lancé par un
    # double-clic ou un raccourci, c'est souvent C:\Windows\System32.
    here = os.path.dirname(os.path.abspath(__file__))
    ini = os.path.join(here, "coco_share.ini")
    root = os.path.abspath(os.path.expanduser(a.dir)) if a.dir else load_dir(ini) or here
    if not os.path.isdir(root):
        print("Folder not found: " + root)
        print("Use: python coco_share.py --dir \"C:\\path\\to\\your\\disks\"")
        return 1
    pin = load_pin(ini, a.pin)
    save_dir(ini, root)
    share = Share(root, pin, a.name[:24], a.read_only)
    srv = Server(("", a.port), Handler)
    srv.share = share
    stop = threading.Event()
    threading.Thread(target=udp_responder, args=(a.port, share.name, stop), daemon=True).start()
    print("=" * 60)
    print(" ESP32-CoCo3 disk share")
    print(" Folder : " + share.root)
    addrs = ", ".join("%s:%d" % (ip, a.port) for ip in local_ips())
    print(" Address: " + (addrs or "port %d" % a.port))
    print(" PIN    : " + pin + "   (type it once on the CoCo: F12 > D > drive > P)")
    print(" Mode   : " + ("read-only" if a.read_only else "read / write (.bak kept)"))
    print(" Change : coco_share.py --dir \"another folder\" (remembered)")
    print(" Ctrl+C to stop. Allow private networks if Windows asks.")
    print("=" * 60, flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    stop.set()
    srv.server_close()
    return 0

if __name__ == "__main__":
    sys.exit(main())

@echo off
rem ESP32-CoCo3 : partage des disquettes du PC (double-clic).
rem Dossier partage : celui garde dans coco_share.ini, sinon ce dossier-ci.
rem Pour en choisir un autre : coco_share.bat --dir "D:\CoCo\Disks"
cd /d "%~dp0"
python "%~dp0coco_share.py" %*
if errorlevel 9009 py "%~dp0coco_share.py" %*
pause

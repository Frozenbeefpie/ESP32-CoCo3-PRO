import sys
d=open(sys.argv[1],'rb').read()
hdr=len(d)%256; d=d[hdr:]
def sec(t,s): o=(t*18+s-1)*256; return d[o:o+256]
fat=sec(17,2)
dirb=b''.join(sec(17,s) for s in range(3,12))
for e in range(72):
    ent=dirb[e*32:e*32+32]
    if ent[0]==0xFF: break
    if ent[0]==0: continue
    name=ent[:8].decode('latin1').strip()+'.'+ent[8:11].decode('latin1').strip()
    g=ent[13]; last=(ent[14]<<8)|ent[15]; data=b''
    while True:
        n=fat[g]; t=g//2; t=t+1 if t>=17 else t; s0=1+(g%2)*9
        if n>=0xC0:
            ns=n&0x1F
            for k in range(ns): data+=sec(t,s0+k)
            data=data[:len(data)-256+last] if ns else data
            break
        for k in range(9): data+=sec(t,s0+k)
        g=n
    print(name, ent[11], len(data))
    if len(sys.argv)>2 and name.upper()==sys.argv[2].upper():
        open(sys.argv[3],'wb').write(data)
